from setuptools import setup

setup(

    name="coberturas",
    version = "0.01",
    description="paquete de agregacion de coberturas",
    author = "Certificación Grupo Bancolombia",
    packages = ["ADD_REGRESION","ADD_REGRESION"]

)
