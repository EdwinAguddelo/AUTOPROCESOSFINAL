def getNextSprintNumber(baseDataSet):
    return (max(baseDataSet['SPRINT'].tolist()))
