from setuptools import setup

setup(

    name="joinTeams",
    version = "0.01",
    description="paquete distribucion de equipos",
    author = "Certificación Grupo Bancolombia",
    packages = ["JOINTEAM","JOINTEAM"]

)
